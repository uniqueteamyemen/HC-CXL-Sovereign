﻿# HC-CXL V2.1 Sovereign Documentation

## 🚀 Sovereign Release Overview

HC-CXL V2.1 represents the mathematically proven extension of the Zenodo heritage lineage (v1.0, v1.1, v1.2, v2.0). This release implements the TSC Theorem with guaranteed operational fidelity.

## 📊 Core Components

### Immutable Validation Core (IVC)
- **W_PMP Kernel**: Worst-Case Performance Management Protocol
- **RDL Engine**: Reliable Damage Limit calculation (95%+ guarantee)
- **DDF Monitor**: Dynamic Deviation Factor tracking
- **Physics Constraints**: Physical system boundary enforcement

### Mathematical Guarantees
- **TSC Theorem**: Temporal Stability under Critical conditions
- **RDL > DDF Condition**: Core stability verification
- **Physics-Bounded Operations**: All computations within physical limits

## 🐳 Docker Deployment

### Quick Start
\\\ash
# Build sovereign image
docker build -f docker/Dockerfile.sovereign -t hc-cxl/sovereign-core:v2.1.0 .

# Run with health checks
docker run -p 8080:8080 hc-cxl/sovereign-core:v2.1.0

# Or use docker-compose
docker-compose -f docker/docker-compose.production.yml up -d
\\\

### Health Monitoring
The system includes automatic health checks verifying:
- RDL > DDF mathematical condition
- Physics constraints compliance
- Temporal stability maintenance

## 🧪 Testing

Run comprehensive tests:
\\\ash
python -m pytest tests/test_sovereign_core.py -v
\\\

## 🔧 API Endpoints

- \GET /health\ - System health status
- \POST /validate\ - Mathematical validation
- \GET /metrics\ - Performance metrics

## 📜 Zenodo Heritage

This release extends and mathematically certifies:
- v1.0 (October 2025) - Foundational models
- v1.1 (October 2025) - Initial refinements  
- v1.2 (November 2025) - Model stabilization
- v2.0 (November 2025) - IVC introduction

---
*HC-CXL Sovereign Team | Mathematically Certified | Zenodo Heritage Preserved*
