# HC-CXL PMP v2.0 Protocol Narrative

## Release purpose and scope
- Version: v2.0
- Objective: Establish sovereign, audit-ready PMP environment with temporal validation, custody recording, and manifest governance.
- Scope: Validators, API, integration tests, custody record, and manifest—sealed and traceable across Windows/Docker.

## Governance upgrades encoded
- Temporal validation:
  - PMP_Temporal_Validator.py and Temporal_Validator.py enforce time-bounded, reproducible checks.
- Custody and manifest:
  - Custody_Record_v2.0.json and root_manifest.json define asset lineage, seals, and onboarding clauses.
- Critique-as-feature:
  - Mounting /app is prohibited in runtime; archive must mount to /data to preserve internal modules.
  - Missing governance docs block validation intentionally to enforce sovereign completeness.

## Sealing and custody ritual
- Archive path (host): D:\HC-CXL\Archive
- Sealing steps:
  1. Compute SHA256 for all protocol assets and write CHECKSUMS_SHA256.txt.
  2. Sign release.tar.gz and record signatures in Custody_Record_v2.0.json.
  3. Timestamp validation and archive closure; include validator outputs verbatim.
- Sovereign custody clauses:
  - No simulated outputs. Only locally executed, verifiable results are accepted.
  - Every attempt (success/failure) is archived as part of the legacy record.

## Operational environments and reproducibility
- Environments: Windows 11 + Docker, Python 3.11.x
- Container policy:
  - /app remains immutable (image modules).
  - Host archive mounts to /data for validator input.
- Repro steps:
  - Baseline: docker run --rm hc-cxl-v2-complete python /app/run_validation.py
  - With archive: docker run --rm -v D:\HC-CXL\Archive:/data hc-cxl-v2-complete python /app/run_validation.py /data

## Audit trail and external validation
- External reviewers must verify checksums and re-run validation locally.
- Onboarding clause:
  - Reviewers provide run logs and checksum diffs.
  - Any critique becomes a mandatory protocol upgrade.

## Change log summary (v2.0)
- Added: Temporal validators, custody record, manifest governance.
- Fixed: Container mount policy (avoid overwriting /app).
- Enforced: Missing narrative/release notes cause validation failure by design.

## Final statement
This narrative is the constitutional preamble for HC-CXL PMP v2.0. It binds the release to sovereign custody, reproducible validation, and external onboarding duties.
