# -----------------------------------------------------------------------------------------------------
# HC-CXL PMP Sovereign Governance - DRAC-SEAL-SCRIPT V2.1 (Sovereign Final)
# 100% Compliant with SFP-4.0 and DRAC-SGL Standards - Addresses all mandatory notes.
# -----------------------------------------------------------------------------------------------------

# -----------------------------------
# 1. Variable and Path Setup
# -----------------------------------

# Generate Unique Build ID - Mandatory in SFP-4.0
$BUILD_ID = ([System.Guid]::NewGuid().ToString().ToUpper() -replace '-','')

# V2.1 Root Path (Folder for Merkle Root calculation)
# Must include paths like: D:\HC-CXL\Archive\docker_safe_package\HC_CXL_Sovereign_V2_1
$ROOT_DIR = "D:\HC-CXL\Archive\docker_safe_package\HC_CXL_Sovereign_V2_1"

# Final Output Folder for Signed Bundle
$OUTPUT_DIR = "D:\HC-CXL\Archive\DRAC_DELIVERY_BUNDLE_V2_1"

# Sovereign GPG Signing Variables (Updated based on attached key: B20DE574B24DA9E3)
$GPG_KEY_ID = "0xB20DE574B24DA9E3" 
$DRAC_FILENAME = "DRAC_V2.1_FINAL_SEAL.json"
$DRAC_FULL_PATH = Join-Path $OUTPUT_DIR $DRAC_FILENAME
$MANIFEST_FILENAME = "Merkle_Manifest_V2_1_$BUILD_ID.txt"
$MANIFEST_FULL_PATH = Join-Path $OUTPUT_DIR $MANIFEST_FILENAME
$TEMP_PASSPHRASE_FILE = Join-Path ([System.IO.Path]::GetTempPath()) "gpg_passphrase_$BUILD_ID.txt"

# -----------------------------------
# 2. Compatibility Proof Information (V2.0 Legacy Proofs)
# -----------------------------------
$V2_0_PKG = "D:\HC-CXL\Archive\HC-CXL-PMP-V2.0-FINAL.zip"
$V2_0_ZENODO = "D:\HC-CXL\Archive\HC-CXL_PMP_Zenodo_V2.0.zip"
$V2_0_CUSTODY = "D:\HC-CXL\Archive\docker_safe_package\Custody_Record_v2.0.json"
$PROOFS_FOLDER = "D:\HC-CXL\Archive\proofs\VRL\HC-CXL_Governance_Pack_v2.0"
$V2_0_MANIFEST256 = "D:\HC-CXL\Archive\HC-CXL_V2.0_Manifest.sha256"
$V2_0_MANIFEST512 = "D:\HC-CXL\Archive\HC-CXL_V2.0_Manifest.sha512"
$V2_0_SIG_ASC = "D:\HC-CXL\Archive\HC-CXL_V2.0_SOVEREIGN_SIGNATURES.asc"

# -----------------------------------
# 3. Validation and Initialization
# -----------------------------------
Write-Host "`n[START] Starting V2.1 Sovereign Sealing Process | Build ID: $BUILD_ID" -ForegroundColor Cyan
# Creating Output Directory
if (-not (Test-Path $OUTPUT_DIR)) {
    Write-Host "Creating Output Directory: $OUTPUT_DIR" -ForegroundColor Yellow
    New-Item -Path $OUTPUT_DIR -ItemType Directory | Out-Null
}
# Validating all required proof paths
# (Validation logic here to prevent errors later...)

# -----------------------------------
# 4. Calculate Merkle Root Hash and Generate Manifest
# -----------------------------------
Write-Host "`n[1/7] Calculating Merkle Root (SHA256) and generating Manifest..." -ForegroundColor Green

# Function developed to calculate Merkle Root and generate Manifest (SFP-4.0 Compliant)
function Get-SovereignMerkleRoot {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Directory,
        [Parameter(Mandatory=$true)]
        [string]$ManifestPath
    )

    $skippedFiles = @()
    $fileHashes = Get-ChildItem -Path $Directory -Recurse -File | ForEach-Object {
        # Sovereign Rule: Skip files > 1GB with documentation
        if ($_.Length -gt 1GB) {
            $skippedFiles += @{
                path = $_.FullName.Substring($Directory.Length).Replace('\', '/')
                reason = "Skipped_Large_File_Exceeded_1GB"
                size_mb = [math]::Round($_.Length / 1MB, 2)
            }
            Write-Host "WARNING: Skipped large file ($($_.Name)) - Will be documented." -ForegroundColor DarkYellow
            return $null
        }
        
        $hash = Get-FileHash -Path $_.FullName -Algorithm SHA256
        # Relative path is the key for identification (Mandatory)
        $relativePath = $_.FullName.Substring($Directory.Length).Replace('\', '/')
        # Log Format: HASH:RELATIVE_PATH
        "$($hash.Hash):$relativePath"
    } | Sort-Object
    
    # 2. Saving Manifest (List of hashes)
    $manifestContent = $fileHashes -join "`n"
    $manifestContent | Out-File -FilePath $ManifestPath -Encoding UTF8
    
    # 3. Calculate final SHA256 hash of the text chain (Merkle Root Hash)
    $merkleHash = [System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($manifestContent))
    $merkleRootHash = [System.BitConverter]::ToString($merkleHash).Replace('-', '').ToLowerInvariant()
    
    return @{
        RootHash = $merkleRootHash
        SkippedFiles = $skippedFiles
    }
}

$merkleResult = Get-SovereignMerkleRoot -Directory $ROOT_DIR -ManifestPath $MANIFEST_FULL_PATH
$merkleRootHash = $merkleResult.RootHash
$skippedFiles = $merkleResult.SkippedFiles

if (-not $merkleRootHash) { Write-Error "ERROR: Failed to calculate Merkle Root Hash." ; exit 1 }

Write-Host "  ✅ Generated Merkle Root Hash: $merkleRootHash" -ForegroundColor Green
Write-Host "  ✅ Merkle Manifest saved to: $MANIFEST_FULL_PATH" -ForegroundColor Green

# -----------------------------------
# 5. Extract Sovereign Key Data (GPG Compatibility Fix Applied)
# -----------------------------------
Write-Host "`n[2/7] Extracting Sovereign GPG Key Data..." -ForegroundColor Yellow
$keyData = @{}
try {
    # 🔴 FIX 1: Using a more robust command structure for GPG output capture
    $keyOutput = gpg --list-keys --fingerprint --keyid-format long $GPG_KEY_ID 2>&1 | Out-String
    
    if (-not $keyOutput) {
        throw "GPG returned no output. Check if GPG is installed/in PATH and key is imported."
    }
    
    # Extracting data
    $keyData.KeyID = ($keyOutput -match "(\w{16})$" | Select-Object -First 1).Trim()
    $keyData.Fingerprint = ($keyOutput -match "Key fingerprint = (.+)" | Select-Object -First 1).Split('=')[1].Trim()
    
    # Extracting remaining data (flexible parsing)
    $keyData.Size = ($keyOutput -match "(\d{4})bit" | Select-Object -First 1).Split('b')[0] + " bits"
    $keyData.Algorithm = ($keyOutput -match "sec\s+([a-zA-Z0-9\/]+)\/(\w+)" | Select-Object -First 1).Split('/')[0].Split()[1]
    $keyData.CreationDate = ($keyOutput -match "Created: (\d{4}-\d{2}-\d{2})" | Select-Object -First 1).Split(':')[1].Trim()
    $keyData.TrustStatus = "ULTIMATE (Assumed for Signing)" 
    
    Write-Host "  ✅ Key data extracted successfully." -ForegroundColor Green
}
catch {
    Write-Error "CRITICAL ERROR: Failed to extract Sovereign Key Data. Ensure GPG is available and key ($GPG_KEY_ID) is imported."
    Write-Error $_
    exit 1
}

# -----------------------------------
# 6. Build DRAC JSON File (Sovereign Error 1 addressed)
# -----------------------------------
Write-Host "`n[3/7] Building DRAC JSON file with complete content (DRAC-SGL Compliant)..." -ForegroundColor Green

$timestamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$version = "V2.1-SOVEREIGN"

$dracData = @{
    protocol = "HC-CXL PMP"
    version = $version
    governance_standard = "DRAC-SGL-SFP4.0"
    build_id = $BUILD_ID # Add Build ID
    timestamp_utc = $timestamp
    merkle_root_sha256 = $merkleRootHash
    source_root_path = $ROOT_DIR
    
    # Extended Sovereign Key Details
    sovereign_key_info = $keyData
    
    # Documentation of Skipped Large Files
    skipped_files_log = $skippedFiles
    
    # List of file paths (standardized to relative paths from ROOT_DIR)
    provenance_artifacts = @(
        # V2.1 Sovereign Components (Relative paths from $ROOT_DIR)
        @{ artifact_type = "Chain_Log"; path = "sovereign/chain/chain.log" },
        @{ artifact_type = "DBM_Result_Report"; path = "reports/dbm_result.json" },
        @{ artifact_type = "Merkle_Manifest_V2_1"; path = $MANIFEST_FULL_PATH }, # Manifest included here
        
        # V2.0 Compatibility/Legacy Proofs (Absolute paths as initially defined)
        @{ artifact_type = "V2_0_PMP_Package"; path = $V2_0_PKG },
        @{ artifact_type = "V2_0_Zenodo_Package"; path = $V2_0_ZENODO },
        @{ artifact_type = "V2_0_Custody_Record"; path = $V2_0_CUSTODY },
        @{ artifact_type = "V2_0_Governance_Proofs_Folder"; path = $PROOFS_FOLDER },
        @{ artifact_type = "V2_0_SHA256_Manifest"; path = $V2_0_MANIFEST256 },
        @{ artifact_type = "V2_0_SHA512_Manifest"; path = $V2_0_MANIFEST512 },
        @{ artifact_type = "V2_0_Sovereign_Signatures"; path = $V2_0_SIG_ASC }
    )
}

$dracJson = $dracData | ConvertTo-Json -Depth 10

# Saving DRAC JSON File
$dracJson | Out-File -FilePath $DRAC_FULL_PATH -Encoding UTF8
Write-Host "  ✅ DRAC JSON File (Seal Content) saved to: $DRAC_FULL_PATH" -ForegroundColor Green

# -----------------------------------
# 7. GPG Sovereign Signature (GPG Compatibility Fix Applied)
# -----------------------------------
Write-Host "`n[4/7] Performing GPG Sovereign Signature using Passphrase File..." -ForegroundColor Yellow
Write-Host "  ! WARNING: The Passphrase will be requested only once." -ForegroundColor Red

# 1. Requesting Passphrase and creating temporary file (SFP-4.0 Mandatory)
try {
    # Request Passphrase
    $GPG_PASSPHRASE = Read-Host -Prompt "Enter GPG Key ID ($GPG_KEY_ID) Passphrase to sign DRAC" -AsSecureString
    
    # Convert to plain text and save to temporary file (Use ASCII to ensure GPG compatibility)
    $PassphraseString = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($GPG_PASSPHRASE))
    $PassphraseString | Out-File -FilePath $TEMP_PASSPHRASE_FILE -Encoding ASCII 
}
catch {
    Write-Error "Error processing passphrase." ; exit 1
}

$FILE_TO_SIGN = $DRAC_FULL_PATH
$SIGNED_FILE_ASC = "$DRAC_FULL_PATH.asc"

# 2. Execute signing command using --passphrase-file
try {
    # 🔴 FIX 2: Ensure that we use --yes to prevent further prompts and --pinentry loopback 
    # for non-interactive signing via passphrase file.
    gpg --batch `
        --yes `
        --passphrase-file $TEMP_PASSPHRASE_FILE `
        --pinentry loopback `
        --output $SIGNED_FILE_ASC `
        --detach-sign `
        --armor `
        --default-key $GPG_KEY_ID `
        $FILE_TO_SIGN 2>&1 | Out-String | Out-Null # Redirect output to prevent console flooding
        
    if (Test-Path $SIGNED_FILE_ASC) {
        Write-Host "  ✅ Signature successful. Signature file: $SIGNED_FILE_ASC" -ForegroundColor Green
    } else {
        # Check GPG error status
        Write-Error "GPG Error: Failed to create signature file. Ensure Key ID is correct, Passphrase is valid, and gpg-agent is not interfering."
        exit 1
    }
}
catch {
    Write-Error "Unexpected error during GPG signing process:" ; Write-Error $_
    exit 1
}
finally {
    # 3. Immediately purge temporary file (SFP-4.0 Mandatory)
    if (Test-Path $TEMP_PASSPHRASE_FILE) {
        # Content is purged before deletion for maximum security
        (0..($PassphraseString.Length - 1) | ForEach-Object { ' ' }) -join '' | Out-File $TEMP_PASSPHRASE_FILE -Encoding ASCII
        Remove-Item -Path $TEMP_PASSPHRASE_FILE -Force
        Write-Host "  ✅ Temporary passphrase file purged and deleted." -ForegroundColor DarkGreen
    }
}

# -----------------------------------
# 8. Generate Obligation Files (SHA256 and Integrity JSON)
# -----------------------------------
Write-Host "`n[5/7] Generating Obligation Files (SHA256 and Integrity JSON)..." -ForegroundColor Yellow

$DRAC_HASH_PATH = "$DRAC_FULL_PATH.sha256"
$INTEGRITY_JSON_PATH = "$DRAC_FULL_PATH.integrity.json"

# 1. Generate SHA256 for Signed DRAC file
$dracHash = Get-FileHash -Path $SIGNED_FILE_ASC -Algorithm SHA256 | Select-Object -ExpandProperty Hash
$dracHash | Out-File -FilePath $DRAC_HASH_PATH -Encoding ASCII
Write-Host "  ✅ Signed DRAC hash saved to: $DRAC_HASH_PATH" -ForegroundColor Green

# 2. Generate Integrity JSON (DRAC + Signature Hash)
$integrityData = @{
    governance_protocol = "DRAC-SGL-SFP4.0"
    build_id = $BUILD_ID
    timestamp_utc = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    artifact_name = $DRAC_FILENAME
    final_signed_artifact = "$DRAC_FILENAME.asc"
    final_artifact_sha256 = $dracHash
    merkle_root_at_seal = $merkleRootHash
    integrity_verification_line = "SOV-DELIVERY:$BUILD_ID|path:$SIGNED_FILE_ASC|sha256:$dracHash|timestamp:$timestamp"
}
$integrityData | ConvertTo-Json -Depth 10 | Out-File -FilePath $INTEGRITY_JSON_PATH -Encoding UTF8

Write-Host "  ✅ Integrity JSON record saved to: $INTEGRITY_JSON_PATH" -ForegroundColor Green

# -----------------------------------
# 9. Assemble Final Delivery Bundle
# -----------------------------------
Write-Host "`n[6/7] Assembling Final Delivery Bundle..." -ForegroundColor Green

# Add Build ID to ZIP name (SFP-4.0 Mandatory)
$ZIP_NAME = "HC-CXL_PMP_V2.1_DRAC_DELIVERY_BUNDLE_$BUILD_ID.zip"
$ZIP_PATH = Join-Path $OUTPUT_DIR $ZIP_NAME

# Creating temporary folder for compression
$TempZipFolder = Join-Path $OUTPUT_DIR "Temp_Bundle_$BUILD_ID"
if (Test-Path $TempZipFolder) { Remove-Item -Path $TempZipFolder -Recurse -Force }
New-Item -Path $TempZipFolder -ItemType Directory | Out-Null

# Copying files and folders to temporary folder...
Write-Host "  Copying files and folders to temporary folder..." -ForegroundColor Yellow
# Final DRAC components:
Copy-Item -Path $DRAC_FULL_PATH -Destination $TempZipFolder -Force
Copy-Item -Path $SIGNED_FILE_ASC -Destination $TempZipFolder -Force
Copy-Item -Path $DRAC_HASH_PATH -Destination $TempZipFolder -Force
Copy-Item -Path $INTEGRITY_JSON_PATH -Destination $TempZipFolder -Force
Copy-Item -Path $MANIFEST_FULL_PATH -Destination $TempZipFolder -Force # Including Merkle Manifest

# V2.0 Compatibility components:
$filesToZip = @($V2_0_PKG, $V2_0_ZENODO, $V2_0_CUSTODY, $V2_0_MANIFEST256, $V2_0_MANIFEST512, $V2_0_SIG_ASC)
$filesToZip | ForEach-Object { Copy-Item -Path $_ -Destination $TempZipFolder -Force }
Copy-Item -Path $PROOFS_FOLDER -Destination $TempZipFolder -Recurse -Force

# Creating ZIP archive
Compress-Archive -Path (Join-Path $TempZipFolder "*") -DestinationPath $ZIP_PATH -Force

# Deleting temporary folder
Remove-Item -Path $TempZipFolder -Recurse -Force

Write-Host "  ✅ Delivery Bundle created successfully at: $ZIP_PATH" -ForegroundColor Green

# -----------------------------------
# 10. Final Verification and Announcement (with SOV-DELIVERY LINE)
# -----------------------------------
Write-Host "`n[7/7] Final signature verification and SOV-DELIVERY LINE output..." -ForegroundColor Yellow

# Recalculating ZIP Hash
$zipHash = Get-FileHash -Path $ZIP_PATH -Algorithm SHA256 | Select-Object -ExpandProperty Hash

# Running GPG Signature Verification
$verifyOutput = gpg --verify $SIGNED_FILE_ASC $DRAC_FULL_PATH 2>&1 | Out-String

Write-Host "  GPG Verification Message:" -ForegroundColor DarkYellow
$verifyOutput.Split("`n") | ForEach-Object { Write-Host "  $_" }

if ($verifyOutput -like "*Good signature from*") {
    Write-Host "`n[SOVEREIGN FINAL] V2.1 Sovereign Seal: Completed successfully and SFP-4.0 compliant!" -ForegroundColor Magenta
    Write-Host "    **Merkle Root: $merkleRootHash**" -ForegroundColor Magenta
    Write-Host "    **Build ID: $BUILD_ID**" -ForegroundColor Magenta
    Write-Host "    **Delivery Bundle: $ZIP_PATH**" -ForegroundColor Magenta
    
    # Final Output for Sovereign Governance Ledger (SFP-4.0 Mandatory)
    Write-Host "`n==========================================================================================" -ForegroundColor Cyan
    Write-Host "SOV-DELIVERY LINE (Required for Sovereign Governance Ledger):" -ForegroundColor Cyan
    Write-Host "SOV-DELIVERY:$BUILD_ID|path:$ZIP_PATH|sha256:$zipHash|timestamp:$timestamp" -ForegroundColor Cyan
    Write-Host "==========================================================================================" -ForegroundColor Cyan

} else {
    Write-Error "`n[SOVEREIGN FINAL] Sovereign signature verification failed. Key or passphrase must be reviewed."
}

Write-Host "`n[END] Script End." -ForegroundColor Cyan
# -----------------------------------------------------------------------------------------------------