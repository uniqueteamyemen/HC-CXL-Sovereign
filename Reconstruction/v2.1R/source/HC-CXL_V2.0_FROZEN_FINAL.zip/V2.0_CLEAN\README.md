# HC-CXL PMP V2.0 - Sovereign Data Execution Framework

## 🎯 Project Overview
**Version**: 2.0 (ComplianceFixed)  
**Status**: Phase 1 - Internal Testing  
**Target**: Zenodo Publication & Commercialization

## 📦 Package Contents

### Core Validation Engine
- `PMP_Temporal_Validator.py` - Main validation logic
- `run_validation.py` - Internal test runner
- `validate_custom.py` - External test interface

### Testing Framework
- `external_templates/` - Pre-built test scenarios
- `run_external_tests.py` - Comprehensive external testing

### Collaboration Ecosystem
- `realtime_forum/` - Bilingual discussion platform
- `deployment_scripts/` - Firebase setup automation

### Deployment
- `Dockerfile` - Containerized execution
- `requirements.txt` - Python dependencies

## 🚀 Quick Start

### Internal Testing (Phase 2)
```bash
# Build Docker image
docker build -t hccxl-pmp-v2.0-final .

# Run internal validation
docker run --rm hccxl-pmp-v2.0-final python run_validation.py
```

### External Testing (Phase 3)
```bash
# Run external test templates
python run_external_tests.py

# Test specific scenarios
python validate_custom.py external_templates/enterprise_scenarios.json
```

### Forum Deployment (Phase 3)
1. Run `deployment_scripts/setup-firebase.ps1`
2. Configure `realtime_forum/firebase-config.js`
3. Deploy forum to web server

## 📋 Development Phases

1. **Phase 1**: PowerShell Integration ✅ (COMPLETE)
2. **Phase 2**: Internal Testing 🧪 (READY)
3. **Phase 3**: External Testing 🌐 (PREPARED)
4. **Phase 4**: Commercialization 💼 (PLANNED)
5. **Phase 5**: Zenodo Publication 📚 (TARGETED)

## 🔧 Technical Specifications

- **W_PMP Tolerance**: ±15%
- **Compliance Threshold**: ±20%
- **Memory Pressure Range**: 0.0-1.0
- **Data Volume Units**: Megabytes (MB)

---
*HC-CXL PMP V2.0 - Sovereign Execution Framework*
*Created: $(Get-Date)*
