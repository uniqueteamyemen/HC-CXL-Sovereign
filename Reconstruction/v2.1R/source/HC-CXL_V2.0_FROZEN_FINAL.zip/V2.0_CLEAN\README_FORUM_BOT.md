Forum Bot / Service Stub for HC-CXL PMP v2.0

Purpose:
- Receives ingestion webhook POSTs at /webhook/ingest
- Verifies token and signature
- Writes a bilingual (EN/AR) summary into a mock store (JSON files)

Environment variables:
- PMP_INGEST_TOKEN (matches ingestion server token)
- PMP_INGEST_SECRET (HMAC secret used by uploader)
- MOCK_STORE_DIR (optional path to store mock JSON posts)

Run locally (dev):
- pip install flask
- PMP_INGEST_TOKEN=SECRET_UPLOADER_KEY PMP_INGEST_SECRET=SECRET_UPLOADER_KEY python realtime_forum_bot/forum_bot_stub.py
