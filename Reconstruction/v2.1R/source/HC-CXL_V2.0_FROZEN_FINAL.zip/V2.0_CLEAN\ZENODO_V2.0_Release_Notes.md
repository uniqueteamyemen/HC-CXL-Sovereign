# HC-CXL PMP v2.0 — Zenodo Release Notes

## Overview
- Title: HC-CXL Protocol Management Platform (PMP) v2.0
- Summary: Sovereign, audit-ready release with temporal validators, custody record, and manifest governance for reproducible verification.

## Version and date
- Version: v2.0
- Release date: 2025-11-17 (local timestamp)

## Core artifacts
- Validators: PMP_Temporal_Validator.py, Temporal_Validator.py
- API: HC_CXL_API.py
- Tests: test_hccxl_integration.py
- Governance: root_manifest.json, Custody_Record_v2.0.json
- Documentation: Protocol_Narrative_V2.0.md, ZENODO_V2.0_Release_Notes.md

## Environment and dependencies
- Python: 3.11.x
- Packages: pandas, numpy, pytest, jsonschema
- Container image: hc-cxl-v2-complete (bundles /app modules)

## Checksums (SHA256)
- release.tar.gz — <SHA256>
- root_manifest.json — <SHA256>
- Custody_Record_v2.0.json — <SHA256>
- PMP_Temporal_Validator.py — <SHA256>
- Temporal_Validator.py — <SHA256>
- HC_CXL_API.py — <SHA256>
- test_hccxl_integration.py — <SHA256>
- Protocol_Narrative_V2.0.md — <SHA256>
- ZENODO_V2.0_Release_Notes.md — <SHA256>

## Validation instructions (for reviewers)
1. Baseline environment validation:
   docker run --rm hc-cxl-v2-complete python /app/run_validation.py
2. Validation with mounted archive:
   docker run --rm -v D:\HC-CXL\Archive:/data hc-cxl-v2-complete python /app/run_validation.py /data
3. Provide:
   - Full console logs
   - Local checksums and signature verification results
   - Any deviations or critiques (treated as mandatory upgrades)

## Onboarding and custody clauses
- No simulated outputs—only local, verified runs.
- Every critique must be encoded into protocol law and reflected in a subsequent release.
- Reviewers acknowledge sovereign custody of artifacts and must retain local logs.

## Change highlights
- Enforced mount policy to preserve internal modules in /app.
- Validation fails if governance docs are missing (intentional completeness gate).
- Enhanced traceability through custody and manifest updates.

## Contact and citation
- Cite as: HC-CXL PMP v2.0 (Unique Team). Include version, checksum, and local validation date.
