﻿# Operational Model — HC-CXL v2.1R

Reference Binding Digest:
B6C66BD929F46B8BF6B920BA6C634972E7B83CA607AD4B5A1042B4AC06A1E203

Assumptions:
- Offline-capable execution
- IVL-based internal verification
- No Docker interaction during build stage
