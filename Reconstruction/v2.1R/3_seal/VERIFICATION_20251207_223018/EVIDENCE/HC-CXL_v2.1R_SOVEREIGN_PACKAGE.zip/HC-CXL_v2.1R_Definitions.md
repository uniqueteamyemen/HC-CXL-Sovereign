﻿# HC-CXL v2.1R — Definitions

- REFERENCE_DIGEST: 'B6C66BD929F46B8BF6B920BA6C634972E7B83CA607AD4B5A1042B4AC06A1E203'
- Pre-Sterilization: Binding logic to immutable dataset digest.
- Semantic Drift: Allowed variation ≤ 0.02.
- W_PMP: Write-Prioritized Memory Processing.
- IVL: Internal Verification Lattice.
